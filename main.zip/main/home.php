<!DOCTYPE html>
<html>
<head>
  <title>Mojai moja</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <meta http-equiv="X-campatible" content="IE-edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
         <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
         <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
         <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
         <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
      </script>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
      </script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
      </script>
        <!-- JQuery -->
       <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- Bootstrap tooltips -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
        <!-- Bootstrap core JavaScript -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <!-- MDB core JavaScript -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>
      <script type="text/javascript">document.write('<script type="text/javascript" src="js/main.js"></script>
</head>
<style>

  body{
    background-color: #ffffcc;
  }
  .container{
    margin-top: 1px;
  }
  h3{
    align-content: center;
    text-align: center;
    padding-top: 15px;
  }
  .restaurant{
    padding-top: 10px;
  }
  hr.rounded {
  border-top: 8px solid #bbb;
  border-radius: 4px;
  margin-top: 5px;
  }
  .gallery {
  -webkit-column-count: 3;
  -moz-column-count: 3;
  column-count: 3;
  -webkit-column-width: 33%;
  -moz-column-width: 33%;
  column-width: 33%; }
  .gallery .pics {
  -webkit-transition: all 350ms ease;
  transition: all 350ms ease; }
  .gallery .animation {
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1); }

  @media (max-width: 450px) {
  .gallery {
  -webkit-column-count: 1;
  -moz-column-count: 1;
  column-count: 1;
  -webkit-column-width: 100%;
  -moz-column-width: 100%;
  column-width: 100%;
  }
  }

  @media (max-width: 400px) {
  .btn.filter {
  padding-left: 1.1rem;
  padding-right: 1.1rem;
  }
  }
</style>
<body>

  <nav class="navbar navbar-dark bg-dark">
    <a class="navbar-brand" href="http://localhost/main/home.php">F.R</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="http://localhost/main/home.php">Home<span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/main/suggestions.php">Food Suggestions</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Discount Offers</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Account</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="http://localhost/main/user_registration.php">Registration</a>
              <a class="dropdown-item" href="http://localhost/main/user_login.php">Login</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="http://localhost/main/user_profile.php">Your Profile</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
   </div>
  </nav>
  <div class="container">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100" src="img/img_nature_wide.jpg" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="img/img_lights_wide.jpg" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="img/img_snow_wide.jpg" alt="Third slide">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
  <div class="container">
    <h3 style="margin-bottom: 20px;">Top foods of the week</h3>
      <!--Carousel Wrapper-->
      <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
        <!--Controls-->
        <div class="controls-top">
          <a class="btn-floating" href="#multi-item-example" data-slide="prev"><i class="fas fa-chevron-left"></i></a>
          <a class="btn-floating" href="#multi-item-example" data-slide="next"><i class="fas fa-chevron-right"></i></a>
        </div>
        <!--/.Controls-->
        <!--Indicators-->
        <ol class="carousel-indicators">
          <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
          <li data-target="#multi-item-example" data-slide-to="1"></li>
        </ol>
        <!--/.Indicators-->
        <!--Slides-->
        <div class="carousel-inner" role="listbox">
        <!--First slide-->
          <div class="carousel-item active">
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c1.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a class="btn btn-primary">7/10</a>
                  </div>
              </div>
            </div>
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c3.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a class="btn btn-primary">8.5/10</a>
                  </div>
              </div>
            </div>
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c6.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4> <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
                    card's content.</p>
                    <a class="btn btn-primary">7.5/10</a>
                  </div>
              </div>
              </div>
              <div class="col-md-3" style="float:left">
                <div class="card mb-2">
                  <img class="card-img-top" src="img/c9.jpeg" alt="Card image cap">
                    <div class="card-body">
                      <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-primary">9/10</a>
                    </div>
                </div>
              </div>
            </div>
            <!--/.First slide-->
            <!--Second slide-->
            <div class="carousel-item">
              <div class="col-md-3" style="float:left">
                <div class="card mb-2">
                  <img class="card-img-top" src="img/c10.jpeg" alt="Card image cap">
                    <div class="card-body">
                      <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-primary">6.5/10</a>
                    </div>
                </div>
              </div>
              <div class="col-md-3" style="float:left">
                <div class="card mb-2">
                  <img class="card-img-top" src="img/c4.jpeg" alt="Card image cap">
                    <div class="card-body">
                      <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-primary">9/10</a>
                    </div>
                </div>
              </div>
              <div class="col-md-3" style="float:left">
                <div class="card mb-2">
                  <img class="card-img-top" src="img/c5.jpeg" alt="Card image cap">
                    <div class="card-body">
                      <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-primary">7.5/10</a>
                    </div>
                </div>
              </div>
              <div class="col-md-3" style="float:left">
                <div class="card mb-2">
                  <img class="card-img-top" src="img/c8.jpeg" alt="Card image cap">
                    <div class="card-body">
                      <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-primary">8/10</a>
                    </div>
                </div>
              </div>
            </div>
        </div>
      </div>
      <!--/.Carousel Wrapper-->
      <div class="container">
        <hr class="rounded">
      </div>
      <div class="container">
        <h3 style="margin-bottom: 20px;">Top Restaurants of the week</h3>
        <div class="restaurant">
        <!--Carousel Wrapper-->
          <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
          <!--Indicators-->
            <ol class="carousel-indicators">
              <li data-target="#multi-item-example1" data-slide-to="0" class="active"></li>
              <li data-target="#multi-item-example2" data-slide-to="1"></li>
            </ol>
            <!--/.Indicators-->
            <!--Slides-->
            <div class="carousel-inner" role="listbox">
            <!--First slide-->
              <div class="carousel-item active">
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r1.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">7/10</a>
                      </div>
                  </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r2.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">8.5/10</a>
                      </div>
                  </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r3.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">6.5/10</a>
                      </div>
                  </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r4.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                          <a class="btn btn-success">9/10</a>
                      </div>
                  </div>
                </div>
              </div>
              <!--/.First slide-->
              <!--Second slide-->
              <div class="carousel-item">
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r5.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">6.5/10</a>
                      </div>
                  </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r6.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">8.5/10</a>
                      </div>
                    </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r7.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">7/10</a>
                      </div>
                  </div>
                </div>
                <div class="col-md-3" style="float:left">
                  <div class="card mb-2">
                    <img class="card-img-top" src="img/r8.jpeg" alt="Card image cap">
                      <div class="card-body">
                        <h4 class="card-title">Card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-success">5.5/10</a>
                      </div>
                  </div>
                </div>
              </div>
              <!--/.Second slide-->
            </div>
            <!--/.Slides-->
            <!--/.Carousel Wrapper-->
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <hr class="rounded">
    </div>
    <div class="container">
      <h3 style="margin-bottom: 20px;">F.R Suggestions</h3>
      <!--Carousel Wrapper-->
      <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
      <!--Indicators-->
        <ol class="carousel-indicators">
          <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
          <li data-target="#multi-item-example" data-slide-to="1"></li>
        </ol>
        <!--/.Indicators-->
        <!--Slides-->
        <div class="carousel-inner" role="listbox">
        <!--First slide-->
          <div class="carousel-item active">
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c1.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a class="btn btn-warning">7/10</a>
                  </div>
                </div>
            </div>
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c3.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a class="btn btn-warning">8.5/10</a>
                  </div>
              </div>
            </div>
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c6.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a class="btn btn-warning">7.5/10</a>
                  </div>
              </div>
            </div>
            <div class="col-md-3" style="float:left">
              <div class="card mb-2">
                <img class="card-img-top" src="img/c9.jpeg" alt="Card image cap">
                  <div class="card-body">
                    <h4 class="card-title">Card title</h4>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a class="btn btn-warning">9/10</a>
                  </div>
              </div>
            </div>
          </div>
          <!--/.First slide-->
        </div>
      </div>
    </div>
    <div class="container">
      <hr class="rounded">
    </div>
    <div class="container">
      <h3 style="margin-bottom: 20px;"> KhadokZz Gallery</h3>
    </div>
    <div class="container">
    <!-- Grid row -->
    <div class="row">
      <div class="gallery" id="gallery">
      <!-- Grid column -->
        <div class="mb-3 pics animation all 2">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(73).jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="mb-3 pics animation all 1">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Vertical/mountain1.jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="mb-3 pics animation all 1">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Vertical/mountain2.jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="mb-3 pics animation all 2">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(35).jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="mb-3 pics animation all 2">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(18).jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="mb-3 pics animation all 1">
          <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Vertical/mountain3.jpg" alt="Card image cap">
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </div>
  <!-- Footer -->
  <footer class="page-footer font-small black pt-4">
  <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
      <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">
          <!-- Content -->
          <h5 class="text-uppercase">F.R</h5>
          <p>Ekhane short bornona hobe somoyer ovabe ekhono likhte pari nai. Khub taratari likhe dibo</p>
        </div>
        <!-- Grid column -->
        <hr class="clearfix w-100 d-md-none pb-3">
        <!-- Grid column -->
          <div class="col-md-3 mb-md-0 mb-3">
          <!-- Links -->
            <h5 class="text-uppercase">Follow Us</h5>
            <ul class="list-unstyled">
              <li>
                <a href="#!">Facebook</a>
              </li>
              <li>
                <a href="#!">Instagram</a>
              </li>
              <li>
                <a href="#!">Youtube</a>
              </li>
              <li>
                <a href="#!">LinkedIn</a>
              </li>
            </ul>
          </div>
          <!-- Grid column -->
          <!-- Grid column -->
          <div class="col-md-3 mb-md-0 mb-3">
          <!-- Links -->
            <h5 class="text-uppercase">Pages</h5>
            <ul class="list-unstyled">
              <li>
                <a href="#!">Discount Offers</a>
              </li>
              <li>
                <a href="#!">Buy one get one offer</a>
              </li>
              <li>
                <a href="#!">Foods Suggestions</a>
              </li>
              <li>
                <a href="#!">Terms and Conditions</a>
              </li>
            </ul>                                                         
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
      <!-- Footer Links -->
      <!-- Copyright -->
    <div class="footer-copyright text-center py-3">©2020
      <a href="https://mdbootstrap.com/"> All right reserved by F.R</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->                                                                         
</body>
</html>