<?php include('server.php')?>

<!DOCTYPE html>
<html>
<head>
	<title>Mojai Moja</title>
</head>
	<title>Mojai moja</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <meta http-equiv="X-campatible" content="IE-edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
         <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
         <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
         <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
         <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
      </script>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
      </script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
      </script>
        <!-- JQuery -->
       <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- Bootstrap tooltips -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
        <!-- Bootstrap core JavaScript -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <!-- MDB core JavaScript -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/js/mdb.min.js"></script>
      <script type="text/javascript">document.write('<script type="text/javascript" src="js/main.js"></script>
</head>
<style>

  body{
    background-color: #ffffcc;
  }
  .container{
    margin-top: 1px;
  }
  h3{
    align-content: center;
    text-align: center;
    padding-top: 30px;
    margin-bottom: 50px;
  }
  .restaurant{
    padding-top: 10px;
  }
  hr.rounded {
  border-top: 8px solid #bbb;
  border-radius: 4px;
  margin-top: 5px;
  }
  .gallery {
  -webkit-column-count: 3;
  -moz-column-count: 3;
  column-count: 3;
  -webkit-column-width: 33%;
  -moz-column-width: 33%;
  column-width: 33%; }
  .gallery .pics {
  -webkit-transition: all 350ms ease;
  transition: all 350ms ease; }
  .gallery .animation {
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1); }

  @media (max-width: 450px) {
  .gallery {
  -webkit-column-count: 1;
  -moz-column-count: 1;
  column-count: 1;
  -webkit-column-width: 100%;
  -moz-column-width: 100%;
  column-width: 100%;
  }
  }

  @media (max-width: 400px) {
  .btn.filter {
  padding-left: 1.1rem;
  padding-right: 1.1rem;
  }
  }
</style>
<body>
	<nav class="navbar navbar-dark bg-dark">
    	<a class="navbar-brand" href="http://localhost/main/home.php">F.R</a>
    		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      		<span class="navbar-toggler-icon"></span>
    		</button>
    	<div class="collapse navbar-collapse" id="navbarSupportedContent">
      		<ul class="navbar-nav mr-auto">
        		<li class="nav-item active">
          			<a class="nav-link" href="http://localhost:8081/main/home.php">Home <span class="sr-only">(current)</span></a>
        		</li>
        		<li class="nav-item">
          			<a class="nav-link" href="http://localhost:8081/main/suggestions.php">Food Suggestions</a>
        		</li>
        		<li class="nav-item">
          			<a class="nav-link" href="#">Discount Offers</a>
        		</li>
        		<li class="nav-item dropdown">
          			<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Account</a>
          			<div class="dropdown-menu" aria-labelledby="navbarDropdown">
            			<a class="dropdown-item" href="http://localhost/main/user_registration.php">Registration</a>
              			<a class="dropdown-item" href="http://localhost/main/user_login.php">Login</a>
              		<div class="dropdown-divider"></div>
              			<a class="dropdown-item" href="http://localhost/main/user_profile.php">Your Profile</a>
          			</div>
        		</li>
        		<li class="nav-item">
          			<a class="nav-link" href="#">About Us</a>
        		</li>
        		<li class="nav-item">
          			<a class="nav-link" href="#">Contact Us</a>
        		</li>
      		</ul>
      		<form class="form-inline my-2 my-lg-0">
        		<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      		</form>
   		</div>
  	</nav>
  	<div class="container">
  		<h3>Please Register First</h3>
  		<form method="post" action="user_registration.php">
        <?php include('errors.php'); ?>
  			<div class="form-group">
    			<label for="name">Name</label>
    			<input type="text" class="form-control" id="name" name="name" aria-describedby="name" placeholder="Enter Your Full Name" required> 
    				<small id="name" class="form-text text-muted"></small>
  			</div>
  			<div class="form-group">
    			<label for="age">Age</label>
    			<input type="number" class="form-control" id="age"  name="age" aria-describedby="age" placeholder="15+" required>
   			</div>
  			<div class="form-group">
  				<<label for="area" id="area" >Your Present Area</label> 
          <!-- value="<?php echo $area;?>" --> -->
  				<div class="dropdown">
      				<select class="form-control form-control-lg" name="area">
      					<option value="Abdullahpur">Abdullahpur</option>
      					<option value="Banani">Banani</option>
      					<option value="Badda">Badda</option>
  						  <option value="Dhaka Cantonment">Dhaka Cantonment</option>
  						  <option value="DakkhinKhan">DakkhinKhan</option>
  						  <option value="Farmgate">Farmgate</option>
  						  <option value="Gulshan">Gulshan</option>
  						  <option value="Hajari">Hajari Bag</option>
  						  <option value="Jatrabari">Jatrabari</option>
  						  <option value="Kolabagan">Kolabagan</option>
  						  <option value="Khilgoan">Khilgoan</option>
  						  <option value="Kafrul">Kafrul</option>
  						  <option value="Khilkhet">Khilkhet</option>
  						  <option value="Lalmatia">Lalmatia</option>
  						  <option value="Motizheel">Motizheel</option>
  						  <option value="Mohammodpur">Mohammodpur</option>
  						  <option value="Mirpur">Mirpur</option>
  						  <option value="New Market">New Market</option>
  						  <option value="Paltan">Paltan</option>
  						  <option value="Pallabi">Pallabi</option>
  						  <option value="Rampura">Rampura</option>
  						  <option value="Ramna">Ramna</option>
  						  <option value="Shutrapur">Shutrapur</option>
  						  <option value="Shahbag">Shahbag</option>        
  						  <option value="Shere Bagla Nagar">Shere bangla Nagar</option>
  						  <option value="Savar">Savar</option>
  						  <option value="Tejgoan">Tejgoan</option>
  						  <option value="Uttar Khan">Uttar Khan</option>
  						  <option value="Uttara">Uttara</option>			
  						  </select>
					</div>
  			</div>
  			<div class="form-group">
    			<label for="exampleInputEmail1">Email address</label>
    			<input type="email" class="form-control" id="email"  name="email" aria-describedby="emailHelp" placeholder="Enter email" value="<?php echo $email;?>" required>
    				<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  			</div>

  			<div class="form-group">
    			<label for="exampleInputPassword1">Password</label>
    			<input type="password" class="form-control" id="pass1" name="pass1"placeholder="Password" required>
  			</div>
  			<div class="form-group">
    			<label for="exampleInputPassword1">Confirm Password</label>
    			<input type="password2" class="form-control" id="pass2"  name="pass2" placeholder="Re-Enter your Password" required=>
  			</div>
  			<div class="form-check">
    			<input type="checkbox" class="form-check-input" id="terms">
    			<label class="form-check-label" for="terms">I agree with F.R terms & Conditions</label>
  			</div>
 		 	<button type="submit" name= "user_registration" class="btn btn-primary">Submit</button>
 		 	<p>Already registered!. <a href="http://localhost:8081/main/user_login.php">Please Login</p>
		</form>
	</div>
	<footer class="page-footer font-small black pt-4">
  <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
      <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">
          <!-- Content -->
          <h5 class="text-uppercase">F.R</h5>
          <p>Ekhane short bornona hobe somoyer ovabe ekhono likhte pari nai. Khub taratari likhe dibo</p>
        </div>
        <!-- Grid column -->
        <hr class="clearfix w-100 d-md-none pb-3">
        <!-- Grid column -->
          <div class="col-md-3 mb-md-0 mb-3">
          <!-- Links -->
            <h5 class="text-uppercase">Follow Us</h5>
            <ul class="list-unstyled">
              <li>
                <a href="#!">Facebook</a>
              </li>
              <li>
                <a href="#!">Instagram</a>
              </li>
              <li>
                <a href="#!">Youtube</a>
              </li>
              <li>
                <a href="#!">LinkedIn</a>
              </li>
            </ul>
          </div>
          <!-- Grid column -->
          <!-- Grid column -->
          <div class="col-md-3 mb-md-0 mb-3">
          <!-- Links -->
            <h5 class="text-uppercase">Pages</h5>
            <ul class="list-unstyled">
              <li>
                <a href="#!">Discount Offers</a>
              </li>
              <li>
                <a href="#!">Buy one get one offer</a>
              </li>
              <li>
                <a href="#!">Foods Suggestions</a>
              </li>
              <li>
                <a href="#!">Terms and Conditions</a>
              </li>
            </ul>                                                         
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
      <!-- Footer Links -->
      <!-- Copyright -->
    <div class="footer-copyright text-center py-3">©2020
      <a href="https://mdbootstrap.com/"> All right reserved by F.R</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->                                   
</body>
</html>