<?php session_start();
//---------registration--------------
$email = "";
$pass = "";
$errors = array();
$database = mysqli_connect('localhost', 'root', '', 'practise');

if (isset($_POST['user_registration'])) {

    $name = mysqli_real_escape_string($database, $_POST['name']);
	$email = mysqli_real_escape_string($database, $_POST['email']);
	$age = mysqli_real_escape_string($database, $_POST['age']);
	$area = mysqli_real_escape_string($database, $_POST['area']);
	$pass1 = mysqli_real_escape_string($database, $_POST['pass1']);
	$pass2 = mysqli_real_escape_string($database, $_POST['pass2']);
	

	if (empty($name)) { array_push($errors, "Name is required"); }
  	if (empty($email)) { array_push($errors, "Email is required"); }
  	if (empty($age)) { array_push($errors, "Age is required"); }
  	if (empty($area)) { array_push($errors, "Area is required"); }
 	if (empty($pass1)) { array_push($errors, "Password is required"); }
  	if ($pass1!= $pass2) {
	array_push($errors, "Your both passwords do not match");
  }


  	$user_check_query = "SELECT * FROM registration WHERE email='$email' LIMIT 1";
  	$result = mysqli_query($database, $user_check_query);
  	$user = mysqli_fetch_assoc($result);


     if ($user['email'] == $email) {
     array_push($errors, "email already exists");
  }


if (count($errors) == 0) {
  	$password = md5($pass1);//encrypt the password before saving in the database

  	$query = "INSERT INTO registration (name, email, age, present_area, pass) 
  			  VALUES('$name', '$email', '$age', '$area', '$pass1')"; // make all of them as string
  			  
  	mysqli_query($database, $query);
  	$_SESSION['name'] = $name;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: home.php');
  }
}


//-----------login------------

if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($database, $_POST['email']);
  $password = mysqli_real_escape_string($database, $_POST['pass']);

  if (empty($email)) {
    array_push($errors, "Your Email is required");
  }
  if (empty($pass)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $pass = md5($password);
    $query = "SELECT * FROM registration WHERE email='$email' AND pass='$password'";

    $results = mysqli_query($database, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in";
      header('location: main/user_profile.php');
    }else {
      array_push($errors, "Wrong email/password combination");
    }
  }
}

?>

?>